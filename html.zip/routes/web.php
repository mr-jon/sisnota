<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::view('/','home');
Route::view('/home','home');

//view de acesso ao aluno
Route::view('/listagem-aluno','aluno.listagem-aluno');
Route::view('/edicao-aluno','aluno.edicao-aluno');
//rotas reais
Route::view('/novo-aluno','aluno.cadastro-aluno');
Route::get('/apagar-aluno/{id}', 'ControllerAluno@apagar');
Route::get('/edicao-aluno/{id}', 'ControllerAluno@editar');
Route::post('/cadastrar-aluno', 'ControllerAluno@cadastrar');



//Route::any('/submit', 'Tutorial@submit');
//Route::any('/', 'Tutorial@principal');



// Route::get('/post', 'Tutorial@showPost');
// Route::get('/get', 'Tutorial@showGet');

//Route::get('/', 'Tutorial@show3');

// Route::get('/{name}', function ($name) {
//     return view('greeting');
// });

// Route::get('/', function () {
//     return view('greeting',["name"=>"Arthu Vinicius"]);
// });

// Route::get('/{id}', 'Tutorial@show1');

// Route::get('/', 'Tutorial@show2');

// Route::get('/', function () {
//     return view('first');
// });

// Route::view('/','first');

// Route::get('/first/{id}', function ($id) {
//     return 'O ID que chegou foi: '.$id;
// });