<nav>
	<div class="nav-wrapper">
		<a href="#" class="brand-logo center">Logo</a>
		<ul id="nav-mobile" class="left hide-on-med-and-down">
			<li><a href="#">Cadastro</a></li>
			<li><a href="#">Movimentos</a></li>
			<li><a href="#">Relatórios</a></li>
		</ul>
	</div>
</nav>     