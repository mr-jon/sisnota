@extends('layouts.app2')


@section('title', 'Home')

@section('content')

@endsection