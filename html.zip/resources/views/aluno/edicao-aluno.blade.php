@extends('layouts.app2')


@section('title', 'Editando Aluno')

@section('content')
<h1>Cadastro do Aluno</h1>
<form method="POST" action="www.google.com">
	<div class="row">
		<div class="col-1">
			<label for="inputAddress">ID</label>
			<input type="text" class="form-control" value="xx" readonly>
		</div>
		<div class="col">
			<label for="inputAddress">Nome completo</label>
			<input type="text" class="form-control" placeholder="Nome">
		</div>
		<div class="col">
			<label for="inputAddress">Data de Nascimento</label>
			<input type="text" class="form-control" placeholder="Data de Nascimento">
		</div>
		<div class="col">
			<label for="inputAddress">CPF</label>
			<input type="text" class="form-control" placeholder="Somente os numeros">
		</div>
	</div>
	<div class="row">
		<div class="col">
			<label for="inputAddress">Naturalidade</label>
			<input type="text" class="form-control" placeholder="Naturalidade">
		</div>
		<div class="col">
			<label for="inputAddress">Nacionalidade</label>
			<input type="text" class="form-control" placeholder="Nacionalidade">
		</div>
		<div class="col">
			<label for="inputAddress">Telefone</label>
			<input type="text" class="form-control" placeholder="Somente os numeros">
		</div>
	</div>

	<div class="row">
		<div class="col">
			<label for="inputAddress">Endereço</label>
			<input type="text" class="form-control" placeholder="Rua do bobos,nº0">
		</div>
		<div class="col">
			<label for="inputAddress">Bairro</label>
			<input type="text" class="form-control" placeholder="Bairro dos bobos">
		</div>
		<div class="form-group col-md-2">
			<label for="inputCEP">CEP</label>
			<input type="text" class="form-control" id="inputCEP">
		</div>
	</div>
	<div class="form-row">
		<div class="form-group col-md-2">
			<label for="inputCity">Cidade</label>
			<input type="text" class="form-control" id="inputCity">
		</div>
		<div class="form-group col-md-4">
			<label for="inputEstado">Estado</label>
			<select id="inputEstado" class="form-control">
				<option selected>Escolher...</option>
				<option>...</option>
			</select>
		</div>
		
	</div>
	<h2>Filiação</h2>
	<div class="row">
		<div class="col">
			<label for="inputAddress">Nome do pai</label>
			<input type="text" class="form-control" placeholder="Nome completo">
		</div>
		<div class="col-md-2">
			<label for="inputAddress">CPF do pai</label>
			<input type="text" class="form-control" placeholder="Somente os numeros">
		</div>
		<div class="col">
			<label for="inputAddress">Nome da mãe</label>
			<input type="text" class="form-control" placeholder="Nome completo">
		</div>
		<div class="col-md-2">
			<label for="inputAddress">CPF do mãe</label>
			<input type="text" class="form-control" placeholder="Somente os numeros">
		</div>
	</div>
	<dir class="row">
		<button type="submit" class="btn btn-primary">Salvar</button>
	</dir>
	
</form>
@endsection
