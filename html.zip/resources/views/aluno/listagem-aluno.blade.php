@extends('layouts.app2')


@section('title', 'Listagem dos Alunos')


@section('content')
<table class="table">
	<thead>
		<tr>
			<th scope="col-md-auto">#</th>
			<th scope="col-md-auto">Primeiro</th>
			<th scope="col-md-auto">Último</th>
			<th scope="col-md-auto">CPF</th>
			<th class="col col-lg-2">Opções</th>
			<th class="col col-lg-2" ><a href="{{ url('/novo-aluno') }}"><button type="button" class="btn btn btn-success">Novo</button></a></th>
		</tr>
	</thead>
	<tbody>
		<tr>

			<th scope="row">1</th>
			<td>Mark</td>
			<td>Otto</td>
			<td>14778996315</td>
			<td>
				<a href="{{ url('/edicao-aluno/{id}') }}"><button type="button" class="btn btn-secondary">Editar</button></a> 
				<a href="{{ url('/apagar-aluno/{id}') }}"><button type="button" class="btn btn-danger">Apagar</button></a>
			</td>
		</tr>
		<tr>
			<th scope="row">2</th>
			<td>Jacob</td>
			<td>Thornton</td>
			<td>95175385225</td>
			<td>
				<a href=""><button type="button" class="btn btn-secondary">Editar</button></a> 
				<a href=""><button type="button" class="btn btn-danger">Apagar</button></a>
			</td>
		</tr>
		<tr>
			<th scope="row">3</th>
			<td>Larry</td>
			<td>the Bird</td>
			<td>36512547895</td>
			<td>
				<a href=""><button type="button" class="btn btn-secondary">Editar</button></a> 
				<a href=""><button type="button" class="btn btn-danger">Apagar</button></a>
			</td>
		</tr>
	</tbody>
</table>
@endsection