<!DOCTYPE html>
<html>
<head>
	<title>Teste Greeting</title>
</head>
<body>
	<p>
		<?php
		print_r($form)
		?>
	</p>
	
	
</h1>
</body>
</html>