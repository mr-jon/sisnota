<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ModelAluno extends Model
{
    public function cadastrar(){

    }

    public function editar(){

    }

    public function apagar(){

    }

    public function listar(){

    }
}
