<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class Tutorial extends Controller
{
   public function show1($id)
   {
   		echo "Hello from controller show ".$id;
   }

   public function show2()
   {
   		return view("first");
   }

   public function show3()
   {	
   		$itens = [1=>"Arthu",2=>"Arthu",3=>"Arthu"];
   		return view("greeting",["itens"=>$itens]);
   }

   public function showGet(Request $request)
   {	
   		$data = $request->input();
   		print_r($data);
   		//return view("greeting",["itens"=>$itens]);
   }

   public function showPost(Request $request)
   {	
   		$data = $request->all();
   		//echo "id: ".$data["id"];
   		//echo "Nome: ".$data["nome"];

   		return view("greeting",["form"=>$data]);
   }

   public function submit(Request $request)
   {	
   		$data = $request->all();
   		return view("greeting",["form"=>$data]);
   }

   public function principal()
   {	
   		return view("form");
   }
}
