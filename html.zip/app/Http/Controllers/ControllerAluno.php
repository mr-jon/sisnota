<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ControllerAluno extends Controller
{
    

    public function cadastrar(Request $request){
    	$data = $request->input();
   		print_r($data);
    }

    public function editar(){

    }

    public function apagar(){

    }

    public function listar(){

    }

}
